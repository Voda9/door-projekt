import { index, route } from "@react-router/dev/routes";

export default [
    
    index("routes/home.jsx"),
    route("products", "routes/products.jsx"),
  route("order/:productId", "routes/order.jsx"),
  route("contact", "routes/contact.jsx"),
  route("admin", "routes/admin.jsx"),
  route("thank-you", "routes/thank-you.jsx"),


];
