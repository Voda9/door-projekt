const VARIANTS = {
  primary: "bg-amber-700 hover:bg-amber-800 text-white",
  outline: "border border-gray-400 text-gray-800 hover:bg-gray-100"
};

export default function Button({ children, variant="primary", ...props }) {
  return (
    <button
      className={`${VARIANTS[variant]} px-5 py-2 rounded-lg transition`}
      {...props}
    >
      {children}
    </button>
  );
}
