/**
 * Button Component for rendering a styled button with different visual variants.
 * @component
 * @param {object} props - Component props.
 * @param {React.ReactNode} props.children - The content displayed inside the button.
 * @param {string} [props.variant="primary"] - Visual style variant of the button. Options:
 *   - "primary": Amber background with white text and hover effect.
 *   - "outline": Gray border with gray text and light hover background.
 * @returns {JSX.Element} The rendered Button component.
 *
 * Features:
 * - Supports multiple visual variants for consistent UI styling.
 * - Automatically applies Tailwind CSS classes for colors, borders, padding, rounded corners, and transitions.
 * - Spreads any additional props (e.g., onClick, type) to the underlying button element.
 * - Designed to be reusable across the application for buttons and calls-to-action.
 */

const VARIANTS = {
  primary: "bg-amber-700 hover:bg-amber-800 text-white",
  outline: "border border-gray-400 text-gray-800 hover:bg-gray-100",
};

export default function Button({ children, variant = "primary", ...props }) {
  return (
    <button
      className={`${VARIANTS[variant]} px-5 py-2 rounded-lg transition`}
      {...props}
    >
      {children}
    </button>
  );
}
