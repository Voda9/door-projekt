/**
 * ProductCard Component for displaying individual product information.
 * @component
 * @param {Object} props - Properties passed to the ProductCard component.
 * @param {Object} props.product - The product to be displayed.
 * @param {string|number} props.product.id - Unique identifier of the product.
 * @param {string} props.product.title - The title of the product.
 * @param {string} props.product.price - The price of the product.
 * @param {string} props.product.description - A brief description of the product.
 * @param {string} [props.product.image] - Optional image URL of the product.
 * @returns {JSX.Element} The rendered ProductCard component.
 *
 * Features:
 * - Displays product image if available.
 * - Shows product title, price, and description.
 * - Includes a link to the order page for the selected product.
 * - Uses React Router Link for client-side navigation.
 * - Styled with Tailwind CSS using rounded corners and shadow.
 */

import { Link } from "react-router";

export default function ProductCard({ product }) {
  return (
    <div className="bg-white shadow rounded-xl overflow-hidden">
      {product.image && (
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-60 object-cover"
        />
      )}

      <div className="p-6">
        <h2 className="text-xl font-bold">{product.title}</h2>
        <p className="text-amber-700 font-semibold">{product.price}</p>
        <p className="text-gray-600 mb-4">{product.description}</p>

        <Link to={`/order/${product.id}`}>
          <button className="bg-amber-700 text-white px-4 py-2 rounded">
            Objednat
          </button>
        </Link>
      </div>
    </div>
  );
}
