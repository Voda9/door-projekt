/**
 * Footer Component for displaying site-wide footer information.
 * @component
 * @returns {JSX.Element} The rendered Footer component.
 *
 * Features:
 * - Displays company information and contact details.
 * - Multiple footer sections: Links, Contact, and Copyright.
 * - Responsive grid layout for desktop and mobile.
 * - Professional styling with gradient background.
 * - Dynamic year for copyright information.
 * - Quick navigation links for easy access.
 */

import { Link } from "react-router";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-b from-gray-900 to-black text-white mt-20">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-3">DoorPro</h3>
            <p className="text-sm text-gray-400">Kvalitní dveře</p>
            <p className="text-gray-400 text-sm leading-relaxed mt-3">
              Nabízíme premium kvalitní dveře a příslušenství pro váš domov.
              Jsme zde pro vás s nejlepší cenou a kvalitou.
            </p>
            <div className="mt-6 flex space-x-4">
              <a
                href="https://facebook.com"
                className="text-gray-400 hover:text-amber-700 transition font-semibold"
                title="Facebook"
              >
                Facebook
              </a>
              <a
                href="https://instagram.com"
                className="text-gray-400 hover:text-amber-700 transition font-semibold"
                title="Instagram"
              >
                Instagram
              </a>
              <a
                href="https://twitter.com"
                className="text-gray-400 hover:text-amber-700 transition font-semibold"
                title="Twitter"
              >
                Twitter
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6 text-white">Navigace</h4>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/"
                  className="text-gray-400 hover:text-amber-700 transition font-medium"
                >
                  Domů
                </Link>
              </li>
              <li>
                <Link
                  to="/products"
                  className="text-gray-400 hover:text-amber-700 transition font-medium"
                >
                  Produkty
                </Link>
              </li>
              <li>
                <Link
                  to="/contact"
                  className="text-gray-400 hover:text-amber-700 transition font-medium"
                >
                  Kontakt
                </Link>
              </li>
              <li>
                <Link
                  to="/admin"
                  className="text-gray-400 hover:text-amber-700 transition font-medium"
                >
                  Admin panel
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6 text-white">
              Kontaktujte nás
            </h4>
            <div className="space-y-4">
              <div className="text-gray-400">
                <p className="font-semibold text-white mb-1">Telefon</p>
                <p>+420 727 123 456</p>
              </div>
              <div className="text-gray-400">
                <p className="font-semibold text-white mb-1">Email</p>
                <a
                  href="mailto:info@doorpro.cz"
                  className="hover:text-amber-700 transition"
                >
                  info@doorpro.cz
                </a>
              </div>
              <div className="text-gray-400">
                <p className="font-semibold text-white mb-1">Adresa</p>
                <p>
                  Hlavní 123
                  <br />
                  120 00 Praha 2
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 py-8">
          {/* Copyright */}
          <div className="text-center text-gray-500 text-sm">
            <p className="mb-2">
              © {currentYear}{" "}
              <span className="text-amber-700 font-semibold">DoorPro</span>.
              Všechna práva vyhrazena.
            </p>
            <p className="text-xs text-gray-600">
              Vyrobeno s láskou pro vaši domácnost
            </p>
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="fixed bottom-8 right-8 bg-amber-700 text-white p-3 rounded-full shadow-lg hover:bg-amber-800 transition opacity-0 hover:opacity-100 duration-300"
        id="backToTop"
      >
        ↑
      </button>
    </footer>
  );
}
