/**
 * Navbar Component for site-wide navigation.
 * @component
 * @returns {JSX.Element} The rendered Navbar component.
 *
 * Features:
 * - Provides navigation links to main application routes.
 * - Uses React Router NavLink for client-side routing.
 * - Includes links to Home, Products, Contact, and Admin pages.
 * - Modern design with gradient background and active link styling.
 * - Responsive layout with hover effects.
 * - Professional branding and visual hierarchy.
 */

import { NavLink } from "react-router";
import { useState } from "react";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-gray-100 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <NavLink
            to="/"
            className="group flex items-center space-x-2 text-gray-800 hover:text-gray-900 transition"
          >
            <div>
              <div className="text-2xl font-bold">DoorPro</div>
              <div className="text-xs text-gray-600 -mt-1">Kvalitní dveře</div>
            </div>
          </NavLink>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive
                    ? "bg-amber-700 text-white"
                    : "text-gray-700 hover:text-gray-900"
                }`
              }
            >
              Domů
            </NavLink>

            <NavLink
              to="/products"
              className={({ isActive }) =>
                `px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive
                    ? "bg-amber-700 text-white"
                    : "text-gray-700 hover:text-gray-900"
                }`
              }
            >
              Produkty
            </NavLink>

            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive
                    ? "bg-amber-700 text-white"
                    : "text-gray-700 hover:text-gray-900"
                }`
              }
            >
              Kontakt
            </NavLink>

            <div className="h-6 border-l border-gray-300 mx-2"></div>

            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  isActive
                    ? "bg-amber-700 text-white"
                    : "text-gray-700 hover:text-gray-900"
                }`
              }
            >
              Admin
            </NavLink>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700 text-2xl"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? "×" : "☰"}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-amber-800 px-4 py-4 space-y-2 rounded-b-lg">
            <NavLink
              to="/"
              className={({ isActive }) =>
                `block px-4 py-3 rounded-lg font-semibold transition-all ${
                  isActive
                    ? "bg-white text-amber-700"
                    : "text-white hover:bg-amber-600"
                }`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Domů
            </NavLink>

            <NavLink
              to="/products"
              className={({ isActive }) =>
                `block px-4 py-3 rounded-lg font-semibold transition-all ${
                  isActive
                    ? "bg-white text-amber-700"
                    : "text-white hover:bg-amber-600"
                }`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Produkty
            </NavLink>

            <NavLink
              to="/contact"
              className={({ isActive }) =>
                `block px-4 py-3 rounded-lg font-semibold transition-all ${
                  isActive
                    ? "bg-white text-amber-700"
                    : "text-white hover:bg-amber-600"
                }`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Kontakt
            </NavLink>

            <div className="border-t border-amber-600 my-2"></div>

            <NavLink
              to="/admin"
              className={({ isActive }) =>
                `block px-4 py-3 rounded-lg font-semibold transition-all ${
                  isActive
                    ? "bg-white text-amber-700"
                    : "text-white hover:bg-amber-600"
                }`
              }
              onClick={() => setMobileMenuOpen(false)}
            >
              Admin
            </NavLink>
          </div>
        )}
      </div>
    </nav>
  );
}
