import { NavLink } from "react-router";

export default function Navbar() {
  return (
    <nav className="bg-white shadow p-4 flex justify-between">
      <NavLink to="/" className="font-bold text-xl">
        DoorPro
      </NavLink>

      <div className="space-x-6">
        <NavLink to="/products">Produkty</NavLink>
        <NavLink to="/contact">Kontakt</NavLink>
        <NavLink to="/admin">Admin</NavLink>
      </div>
    </nav>
  );
}
