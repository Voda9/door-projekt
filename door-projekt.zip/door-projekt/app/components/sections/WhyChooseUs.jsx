/**
 * WhyChooseUs Component for highlighting company advantages.
 * @component
 * @returns {JSX.Element} The rendered WhyChooseUs component.
 *
 * Features:
 * - Displays key benefits of the company in a structured layout.
 * - Includes sections for experience, professional installation, and quality assurance.
 * - Uses responsive grid layout for feature cards.
 * - Styled with Tailwind CSS including hover shadow effects.
 * - Designed to build trust and support marketing messaging.
 */

export default function WhyChooseUs() {
  return (
    <section className="bg-gray-50 py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Proč si vybrat právě nás?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Spojujeme kvalitu, zkušenosti a individuální přístup ke každému
            projektu.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition">
            <h3 className="text-xl font-semibold mb-3">15+ let zkušeností</h3>
            <p className="text-gray-600">
              Dlouholeté zkušenosti s montáží a prodejem tisíců dveří po celé
              České republice.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition">
            <h3 className="text-xl font-semibold mb-3">Profesionální montáž</h3>
            <p className="text-gray-600">
              Certifikovaní montážníci zajistí precizní instalaci bez
              kompromisů.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition">
            <h3 className="text-xl font-semibold mb-3">Záruka kvality</h3>
            <p className="text-gray-600">
              Nabízíme pouze ověřené produkty s dlouhou životností a plnou
              zárukou.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
