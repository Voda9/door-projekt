/**
 * Hero Component for displaying the main promotional section.
 * @component
 * @returns {JSX.Element} The rendered Hero component.
 *
 * Features:
 * - Displays main heading and introductory text.
 * - Includes call-to-action buttons for Products and Contact pages.
 * - Uses React Router Link for client-side navigation.
 * - Responsive layout with centered content.
 * - Styled with Tailwind CSS gradient background and hover effects.
 * - Designed as the main landing section of the homepage.
 */

import { Link } from "react-router";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white">
      <div className="container mx-auto px-6 py-32 text-center">
        <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6">
          Kvalitní dveře pro moderní bydlení
        </h1>

        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-10">
          Interiérové, bezpečnostní i protipožární dveře s profesionální montáží
          a dlouhou životností.
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/products">
            <button className="bg-amber-600 hover:bg-amber-700 px-8 py-3 rounded-lg font-semibold transition">
              Prohlédnout nabídku
            </button>
          </Link>

          <Link to="/contact">
            <button className="border border-gray-400 px-8 py-3 rounded-lg hover:bg-white hover:text-black transition">
              Nezávazná poptávka
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
