export default function FormTextarea({
  label,
  name,
  placeholder,
  required = false
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">
        {label}
      </label>
      <textarea
        name={name}
        required={required}
        rows="5"
        placeholder={placeholder}
        className="w-full border border-gray-300 rounded-lg px-4 py-3 
                   focus:outline-none focus:ring-2 focus:ring-amber-500 
                   focus:border-amber-500 transition resize-none"
      />
    </div>
  );
}
