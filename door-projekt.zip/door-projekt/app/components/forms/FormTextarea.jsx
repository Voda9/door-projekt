/**
 * FormTextarea Component for rendering reusable textarea fields.
 * @component
 * @param {Object} props - Properties passed to the FormTextarea component.
 * @param {string} props.label - The label displayed above the textarea field.
 * @param {string} props.name - The name attribute of the textarea element.
 * @param {string} props.placeholder - Placeholder text for the textarea field.
 * @param {boolean} [props.required=false] - Determines if the textarea is required.
 * @returns {JSX.Element} The rendered FormTextarea component.
 *
 * Features:
 * - Renders a labeled textarea field for form usage.
 * - Supports customizable placeholder text.
 * - Optional required attribute for validation.
 * - Fixed number of rows for consistent layout.
 * - Styled using Tailwind CSS with focus ring and transition effects.
 * - Resize disabled for improved design consistency.
 */

export default function FormTextarea({
  label,
  name,
  placeholder,
  required = false,
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">{label}</label>
      <textarea
        name={name}
        required={required}
        rows="5"
        placeholder={placeholder}
        className="w-full border border-gray-300 rounded-lg px-4 py-3 
                   focus:outline-none focus:ring-2 focus:ring-amber-500 
                   focus:border-amber-500 transition resize-none"
      />
    </div>
  );
}
