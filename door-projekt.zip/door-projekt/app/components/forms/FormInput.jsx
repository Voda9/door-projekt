export default function FormInput({
  label,
  name,
  type = "text",
  placeholder,
  required = false
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">
        {label}
      </label>
      <input
        type={type}
        name={name}
        required={required}
        placeholder={placeholder}
        className="w-full border border-gray-300 rounded-lg px-4 py-3 
                   focus:outline-none focus:ring-2 focus:ring-amber-500 
                   focus:border-amber-500 transition"
      />
    </div>
  );
}
