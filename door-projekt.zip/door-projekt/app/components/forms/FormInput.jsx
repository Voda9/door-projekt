/**
 * FormInput Component for rendering reusable input fields.
 * @component
 * @param {Object} props - Properties passed to the FormInput component.
 * @param {string} props.label - The label displayed above the input field.
 * @param {string} props.name - The name attribute of the input element.
 * @param {string} [props.type="text"] - The type of the input element.
 * @param {string} props.placeholder - Placeholder text for the input field.
 * @param {boolean} [props.required=false] - Determines if the input is required.
 * @returns {JSX.Element} The rendered FormInput component.
 *
 * Features:
 * - Renders a labeled input field for form usage.
 * - Supports customizable input type and placeholder text.
 * - Optional required attribute for validation.
 * - Styled using Tailwind CSS with focus ring and transition effects.
 * - Designed as a reusable form component for consistent UI.
 */

export default function FormInput({
  label,
  name,
  type = "text",
  placeholder,
  required = false,
}) {
  return (
    <div>
      <label className="block text-sm font-medium mb-2">{label}</label>
      <input
        type={type}
        name={name}
        required={required}
        placeholder={placeholder}
        className="w-full border border-gray-300 rounded-lg px-4 py-3 
                   focus:outline-none focus:ring-2 focus:ring-amber-500 
                   focus:border-amber-500 transition"
      />
    </div>
  );
}
