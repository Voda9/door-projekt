import { Form } from "react-router";
import FormInput from "./FormInput";
import FormTextarea from "./FormTextarea";

export default function ContactForm() {
  return (
    <div className="bg-white w-full max-w-2xl p-10 rounded-2xl shadow-xl">

      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-3">
          Kontaktujte nás
        </h1>
        <p className="text-gray-600">
          Máte dotaz nebo zájem o nezávaznou nabídku?
          Napište nám a ozveme se vám.
        </p>
      </div>

      <Form method="post" className="space-y-6">

        <FormInput
          label="Jméno"
          name="name"
          required
          placeholder="Jan Novák"
        />

        <FormInput
          label="Email"
          name="email"
          type="email"
          required
          placeholder="jan@email.cz"
        />

        <FormInput
          label="Předmět"
          name="subject"
          placeholder="Např. nabídka interiérových dveří"
        />

        <FormTextarea
          label="Zpráva"
          name="message"
          required
          placeholder="Popište vaši poptávku..."
        />

        <button
          type="submit"
          className="w-full bg-amber-600 hover:bg-amber-700 text-white 
                     font-semibold py-3 rounded-lg transition 
                     shadow-md hover:shadow-lg"
        >
          Odeslat zprávu
        </button>

      </Form>
    </div>
  );
}
