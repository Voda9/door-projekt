/**
 * OrderForm Component for submitting product orders.
 * @component
 * @param {Object} props - Properties passed to the OrderForm component.
 * @param {string|number} props.productId - The unique identifier of the selected product.
 * @returns {JSX.Element} The rendered OrderForm component.
 *
 * Features:
 * - Displays an order form for selected product inquiries.
 * - Shows selected product ID in a highlighted information box.
 * - Uses React Router Form for form submission handling.
 * - Collects customer details such as name, email, phone, and installation date.
 * - Includes installation address and optional note field.
 * - Responsive grid layout for better input organization.
 * - Styled with Tailwind CSS including hover and shadow effects.
 */

import { Form } from "react-router";
import FormInput from "./FormInput";
import FormTextarea from "./FormTextarea";

export default function OrderForm({ productId }) {
  return (
    <div className="bg-white w-full max-w-4xl p-10 rounded-2xl shadow-xl">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold mb-3">Objednávka dveří</h1>
        <p className="text-gray-600">
          Vyplňte formulář a připravíme vám cenovou nabídku.
        </p>
      </div>

      {/* Informace o produktu */}
      <div className="bg-gray-100 p-6 rounded-lg mb-8">
        <p className="text-sm text-gray-500">Vybraný produkt</p>
        <p className="text-lg font-semibold">Produkt ID: {productId}</p>
      </div>

      <Form method="post" className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <FormInput
            label="Jméno"
            name="name"
            required
            placeholder="Jan Novák"
          />

          <FormInput
            label="Email"
            name="email"
            type="email"
            required
            placeholder="jan@email.cz"
          />
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <FormInput
            label="Telefon"
            name="phone"
            required
            placeholder="+420 777 123 456"
          />

          <FormInput
            label="Datum montáže"
            name="installation_date"
            type="date"
            required
          />
        </div>

        <FormInput
          label="Adresa montáže"
          name="address"
          required
          placeholder="Ulice 123, Město"
        />

        <FormTextarea
          label="Poznámka"
          name="note"
          placeholder="Upřesnění požadavků..."
        />

        <button
          type="submit"
          className="w-full bg-amber-600 hover:bg-amber-700 text-white 
                     font-semibold py-3 rounded-lg transition 
                     shadow-md hover:shadow-lg"
        >
          Odeslat objednávku
        </button>
      </Form>
    </div>
  );
}
