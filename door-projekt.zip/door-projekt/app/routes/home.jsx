/**
 * Home Page Component for the main landing page of the website.
 * @component
 * @returns {JSX.Element} The rendered Home page containing Hero and WhyChooseUs sections.
 *
 * Features:
 * - Renders the Hero section as the main promotional banner with heading, description, and call-to-action buttons.
 * - Renders the WhyChooseUs section highlighting key benefits or features of the service/company.
 * - Composes the page from reusable components for better maintainability and scalability.
 * - Minimal wrapper using React fragments for clean structure.
 * - Designed as the primary entry point for visitors to the website.
 */

import Hero from "../components/sections/Hero";
import WhyChooseUs from "../components/sections/WhyChooseUs";

export default function Home() {
  return (
    <>
      <Hero />
      <WhyChooseUs />
    </>
  );
}
