/**
 * ThankYou Page Component displayed after a successful form submission or order.
 * @component
 * @returns {JSX.Element} The rendered ThankYou page with confirmation message and navigation button.
 *
 * Features:
 * - Displays a centered thank-you message confirming the user's action (e.g., order submission).
 * - Provides a button linking back to the homepage using React Router `Link`.
 * - Uses Tailwind CSS for full-screen centering, spacing, typography, and button styling.
 * - Minimal and user-friendly confirmation page for positive feedback.
 * - Designed to reassure users that their submission was successful.
 */

import { Link } from "react-router";

export default function ThankYou() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-4">Děkujeme za objednávku!</h1>

        <Link to="/">
          <button className="bg-amber-700 text-white px-6 py-3 rounded">
            Zpět na hlavní stránku
          </button>
        </Link>
      </div>
    </div>
  );
}
