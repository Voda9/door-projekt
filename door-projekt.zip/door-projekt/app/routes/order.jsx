/**
 * Order Page Component for submitting a product order.
 * @component
 * @returns {JSX.Element} The rendered Order page containing the OrderForm component.
 *
 * Features:
 * - Displays a full-page order form centered on the screen.
 * - Uses Tailwind CSS for layout, spacing, background color, and responsive design.
 * - Extracts `productId` from the URL parameters using `useParams`.
 * - Action:
 *   - `action()` handles form submission from OrderForm.
 *   - Extracts customer details including name, email, phone, address, installation date, and optional note.
 *   - Inserts a new order record into the `orders` table in the database, associated with the selected product.
 *   - Redirects the user to the "/thank-you" page after successful submission.
 * - Reusable OrderForm component is imported and displayed within the page.
 * - Designed for a smooth and user-friendly ordering process.
 */

import { useParams, redirect } from "react-router";
import { sql } from "../api/sql";
import OrderForm from "../components/forms/OrderForm";

export async function action({ request, params }) {
  const data = await request.formData();

  await sql(`
    INSERT INTO orders
    (product_id, name, email, phone, address, installation_date, note)
    VALUES
    ('${params.productId}',
     '${data.get("name")}',
     '${data.get("email")}',
     '${data.get("phone")}',
     '${data.get("address")}',
     '${data.get("installation_date")}',
     '${data.get("note")}')
  `);

  return redirect("/thank-you");
}

export default function Order() {
  const { productId } = useParams();

  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center px-6 py-20">
      <OrderForm productId={productId} />
    </section>
  );
}
