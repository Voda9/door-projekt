import { useParams, redirect } from "react-router";
import { sql } from "../api/sql";
import OrderForm from "../components/forms/OrderForm";

export async function action({ request, params }) {
  const data = await request.formData();

  await sql(`
    INSERT INTO orders
    (product_id, name, email, phone, address, installation_date, note)
    VALUES
    ('${params.productId}',
     '${data.get("name")}',
     '${data.get("email")}',
     '${data.get("phone")}',
     '${data.get("address")}',
     '${data.get("installation_date")}',
     '${data.get("note")}')
  `);

  return redirect("/thank-you");
}

export default function Order() {
  const { productId } = useParams();

  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center px-6 py-20">
      <OrderForm productId={productId} />
    </section>
  );
}
