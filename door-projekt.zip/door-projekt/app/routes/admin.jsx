/**
 * Admin Page Component for managing products in the application.
 * @component
 * @returns {JSX.Element} The rendered Admin component with product form and list.
 *
 * Features:
 * - Displays a product management interface with form for creating or editing products.
 * - Shows a list of all products loaded from the database, with edit and delete options.
 * - Loader:
 *   - `loader()` fetches all products from the database, ordered by newest first.
 * - Action:
 *   - `action()` handles form submissions for saving (create/update) and deleting products.
 *   - Validates required fields (title and price) before saving.
 *   - Returns success or error messages for user feedback.
 * - Form:
 *   - Inputs for product title, price, description, and image URL.
 *   - Handles both creating new products and editing existing ones.
 *   - Cancel button resets editing state.
 * - Product List:
 *   - Displays product image, title, price, and description.
 *   - Edit button populates the form with selected product data.
 *   - Delete button confirms before removing product from database.
 * - Uses React Router `Form`, `useLoaderData`, and `useActionData` for data handling.
 * - Styled with Tailwind CSS for layout, spacing, colors, hover effects, and responsive grid.
 * - Provides clear user feedback with green success messages and red error messages.
 */

import { useLoaderData, useActionData, Form, redirect } from "react-router";
import { sql } from "../api/sql";
import { useState } from "react";

export async function loader() {
  return await sql("SELECT * FROM products ORDER BY id DESC");
}

export async function action({ request }) {
  const formData = await request.formData();
  const actionType = formData.get("actionType");

  try {
    if (actionType === "delete") {
      const id = formData.get("id");
      await sql(`DELETE FROM products WHERE id = ${id}`);
      return { success: true, message: "Produkt smazán" };
    }

    if (actionType === "save") {
      const id = formData.get("id");
      const title = formData.get("title");
      const price = formData.get("price");
      const description = formData.get("description");
      const image = formData.get("image");

      if (!title || !price) {
        return { error: "Název a cena jsou povinné" };
      }

      if (id) {
        // Update existing product
        const query = `UPDATE products SET title='${title}', price='${price}', description='${description}', image='${image}' WHERE id=${id}`;
        await sql(query);
        return { success: true, message: "Produkt aktualizován" };
      } else {
        // Create new product
        const query = `INSERT INTO products (title, price, description, image) VALUES ('${title}', '${price}', '${description}', '${image}')`;
        await sql(query);
        return { success: true, message: "Produkt vytvořen" };
      }
    }
  } catch (error) {
    return { error: "Chyba: " + error.message };
  }
}

export default function Admin() {
  const products = useLoaderData();
  const actionData = useActionData();
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    id: "",
    title: "",
    price: "",
    description: "",
    image: "",
  });

  const handleEdit = (product) => {
    setEditingId(product.id);
    setFormData({
      id: product.id,
      title: product.title,
      price: product.price,
      description: product.description,
      image: product.image || "",
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    setFormData({ id: "", title: "", price: "", description: "", image: "" });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Správa produktů</h1>

      {actionData?.success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
          {actionData.message}
        </div>
      )}
      {actionData?.error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          {actionData.error}
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-8">
        {/* Product Form */}
        <div className="md:col-span-1">
          <div className="bg-white shadow rounded-lg p-6 sticky top-4">
            <h2 className="text-xl font-bold mb-4">
              {editingId ? "Upravit produkt" : "Nový produkt"}
            </h2>

            <Form method="post" className="space-y-4">
              <input type="hidden" name="actionType" value="save" />
              {editingId && (
                <input type="hidden" name="id" value={formData.id} />
              )}

              <div>
                <label className="block text-sm font-semibold mb-1">
                  Název *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2"
                  placeholder="Název produktu"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">
                  Cena *
                </label>
                <input
                  type="text"
                  name="price"
                  value={formData.price}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2"
                  placeholder="Cena (např. 999 Kč)"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">
                  Popis
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2 h-24"
                  placeholder="Popis produktu"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">
                  URL obrázku
                </label>
                <input
                  type="text"
                  name="image"
                  value={formData.image}
                  onChange={handleChange}
                  className="w-full border rounded px-3 py-2"
                  placeholder="https://..."
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-amber-700 text-white px-4 py-2 rounded font-semibold hover:bg-amber-800"
                >
                  {editingId ? "Uložit" : "Vytvořit"}
                </button>
                {editingId && (
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="flex-1 bg-gray-400 text-white px-4 py-2 rounded font-semibold hover:bg-gray-500"
                  >
                    Zrušit
                  </button>
                )}
              </div>
            </Form>
          </div>
        </div>

        {/* Products List */}
        <div className="md:col-span-2">
          <div className="space-y-4">
            {products.length === 0 ? (
              <p className="text-gray-500">Žádné produkty</p>
            ) : (
              products.map((product) => (
                <div
                  key={product.id}
                  className={`bg-white shadow rounded-lg p-4 flex gap-4 ${
                    editingId === product.id ? "border-2 border-amber-700" : ""
                  }`}
                >
                  {product.image && (
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-24 h-24 object-cover rounded"
                    />
                  )}

                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{product.title}</h3>
                    <p className="text-amber-700 font-semibold">
                      {product.price}
                    </p>
                    <p className="text-gray-600 text-sm">
                      {product.description}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2 justify-center">
                    <button
                      onClick={() => handleEdit(product)}
                      className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 font-semibold text-sm"
                    >
                      Upravit
                    </button>

                    <Form
                      method="post"
                      onSubmit={(e) => {
                        if (
                          !window.confirm(
                            "Opravdu chcete smazat tento produkt?",
                          )
                        ) {
                          e.preventDefault();
                        }
                      }}
                    >
                      <input type="hidden" name="actionType" value="delete" />
                      <input type="hidden" name="id" value={product.id} />
                      <button
                        type="submit"
                        className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 font-semibold text-sm w-full"
                      >
                        Smazat
                      </button>
                    </Form>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
