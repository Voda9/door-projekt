import { redirect } from "react-router";
import { sql } from "../api/sql";
import ContactForm from "../components/forms/ContactForm";

export async function action({ request }) {
  const data = await request.formData();

  await sql(`
    INSERT INTO contact_messages (name, email, subject, message)
    VALUES (
      '${data.get("name")}',
      '${data.get("email")}',
      '${data.get("subject")}',
      '${data.get("message")}'
    )
  `);

  return redirect("/thank-you");
}

export default function Contact() {
  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center px-6 py-20">
      <ContactForm />
    </section>
  );
}
