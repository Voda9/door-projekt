/**
 * Contact Page Component for submitting messages through a contact form.
 * @component
 * @returns {JSX.Element} The rendered Contact page containing the ContactForm component.
 *
 * Features:
 * - Displays a full-page contact form centered on the screen.
 * - Uses Tailwind CSS for layout, spacing, background color, and responsive design.
 * - Action:
 *   - `action()` handles form submission from ContactForm.
 *   - Extracts name, email, subject, and message from the submitted form data.
 *   - Inserts a new record into the `contact_messages` table in the database.
 *   - Redirects the user to the "/thank-you" page after successful submission.
 * - Reusable ContactForm component is imported and displayed within the page.
 * - Provides a clean and minimal interface for users to send inquiries or messages.
 */

import { redirect } from "react-router";
import { sql } from "../api/sql";
import ContactForm from "../components/forms/ContactForm";

export async function action({ request }) {
  const data = await request.formData();

  await sql(`
    INSERT INTO contact_messages (name, email, subject, message)
    VALUES (
      '${data.get("name")}',
      '${data.get("email")}',
      '${data.get("subject")}',
      '${data.get("message")}'
    )
  `);

  return redirect("/thank-you");
}

export default function Contact() {
  return (
    <section className="min-h-screen bg-gray-50 flex items-center justify-center px-6 py-20">
      <ContactForm />
    </section>
  );
}
