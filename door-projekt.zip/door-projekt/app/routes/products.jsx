import { useLoaderData } from "react-router";
import { sql } from "../api/sql";
import ProductCard from "../components/products/ProductCard";

export async function loader() {
  return await sql("SELECT * FROM products");
}

export default function Products() {
  const products = useLoaderData();

  return (
    <div className="container mx-auto py-16 grid md:grid-cols-3 gap-8">
      {products.map(p => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}
