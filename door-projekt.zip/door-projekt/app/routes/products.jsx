/**
 * Products Page Component for displaying a list of all products with filtering.
 * @component
 * @returns {JSX.Element} The rendered Products page with filters and a grid of ProductCard components.
 *
 * Features:
 * - Loader:
 *   - `loader()` fetches all products from the database.
 * - Filter & Search:
 *   - Search by product title/name
 *   - Filter by price range (min/max)
 *   - Sort options (price low-to-high, high-to-low, newest, alphabetical)
 * - Renders products in a responsive grid layout using Tailwind CSS.
 * - Uses the `ProductCard` component for each product to display image, title, price, and description.
 * - Designed to provide a clean, organized, and visually appealing product listing with filtering capabilities.
 * - Fully responsive for desktop and mobile devices.
 * - Facilitates navigation and browsing for users looking at available products.
 */

import { useLoaderData } from "react-router";
import { sql } from "../api/sql";
import ProductCard from "../components/products/ProductCard";
import { useState, useMemo } from "react";

export async function loader() {
  return await sql("SELECT * FROM products");
}

export default function Products() {
  const products = useLoaderData();
  const [searchTerm, setSearchTerm] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let filtered = products.filter((p) => {
      // Search filter
      const matchesSearch = p.title
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

      // Price filter
      const price = parseFloat(p.price.replace(/\s|Kč/g, "")) || 0;
      const min = minPrice ? parseFloat(minPrice) : 0;
      const max = maxPrice ? parseFloat(maxPrice) : Infinity;
      const matchesPrice = price >= min && price <= max;

      return matchesSearch && matchesPrice;
    });

    // Sort
    switch (sortBy) {
      case "priceAsc":
        filtered.sort((a, b) => {
          const priceA = parseFloat(a.price.replace(/\s|Kč/g, "")) || 0;
          const priceB = parseFloat(b.price.replace(/\s|Kč/g, "")) || 0;
          return priceA - priceB;
        });
        break;
      case "priceDesc":
        filtered.sort((a, b) => {
          const priceA = parseFloat(a.price.replace(/\s|Kč/g, "")) || 0;
          const priceB = parseFloat(b.price.replace(/\s|Kč/g, "")) || 0;
          return priceB - priceA;
        });
        break;
      case "alphabetical":
        filtered.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "newest":
      default:
        filtered.sort((a, b) => b.id - a.id);
        break;
    }

    return filtered;
  }, [products, searchTerm, minPrice, maxPrice, sortBy]);

  const handleResetFilters = () => {
    setSearchTerm("");
    setMinPrice("");
    setMaxPrice("");
    setSortBy("newest");
  };

  return (
    <div className="container mx-auto py-8 px-4">
      {/* Filters Section */}
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <h2 className="text-lg font-bold mb-6">Filtry a vyhledávání</h2>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {/* Search */}
          <div>
            <label className="block text-sm font-semibold mb-2">
              Hledání podle názvu
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Např. dveře..."
              className="w-full border rounded px-3 py-2"
            />
          </div>

          {/* Min Price */}
          <div>
            <label className="block text-sm font-semibold mb-2">
              Min. cena
            </label>
            <input
              type="number"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
              placeholder="0"
              className="w-full border rounded px-3 py-2"
            />
          </div>

          {/* Max Price */}
          <div>
            <label className="block text-sm font-semibold mb-2">
              Max. cena
            </label>
            <input
              type="number"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              placeholder="99999"
              className="w-full border rounded px-3 py-2"
            />
          </div>

          {/* Sort */}
          <div>
            <label className="block text-sm font-semibold mb-2">Řazení</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full border rounded px-3 py-2"
            >
              <option value="newest">Nejnovější</option>
              <option value="priceAsc">Cena: Nízká → Vysoká</option>
              <option value="priceDesc">Cena: Vysoká → Nízká</option>
              <option value="alphabetical">Abecedně</option>
            </select>
          </div>

          {/* Reset Button */}
          <div className="flex items-end">
            <button
              onClick={handleResetFilters}
              className="w-full bg-gray-400 text-white px-4 py-2 rounded font-semibold hover:bg-gray-500"
            >
              Resetovat filtry
            </button>
          </div>
        </div>

        {/* Results count */}
        <p className="text-sm text-gray-600 mt-4">
          Nalezeno produktů:{" "}
          <span className="font-bold">{filteredProducts.length}</span>
        </p>
      </div>

      {/* Products Grid */}
      <div className="grid md:grid-cols-3 gap-8">
        {filteredProducts.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <p className="text-gray-500 text-lg">
              Žádné produkty neodpovídají vašim kritériím.
            </p>
          </div>
        ) : (
          filteredProducts.map((p) => <ProductCard key={p.id} product={p} />)
        )}
      </div>
    </div>
  );
}
